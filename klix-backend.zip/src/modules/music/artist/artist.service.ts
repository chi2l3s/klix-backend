import { Injectable } from '@nestjs/common'
import translitRusEng from 'translit-rus-eng'

import { PrismaService } from '@/src/core/prisma/prisma.service'

import { CreateArtistInput } from './inputs/create-artist.input'

@Injectable()
export class ArtistService {
	constructor(private readonly prisma: PrismaService) {}

	async createArtist(input: CreateArtistInput) {
		const { name } = input

		const slug = translitRusEng(name, { slugify: true })

		const existingArtist = await this.prisma.artist.findUnique({
			where: {
				slug,
			},
		})

		if (existingArtist) {
			return existingArtist
		}

		const artist = await this.prisma.artist.create({
			data: {
				name,
				slug,
			},
		})

		return artist
	}

	async getArtists() {
		const artists = await this.prisma.artist.findMany()

		return artists
    }

    async getArtistBySlug(slug: string) {
        const artist = await this.prisma.artist.findUnique({
            where: {
                slug,
            },
			include: {
				albums: {
					include: {
						songs: true
					}
				}
			}
        })

        return artist
    }
}
