import { Field, ObjectType } from '@nestjs/graphql'

import { Song } from '@/prisma/generated'

import { ArtistModel } from '../../artist/models/artist.model'
import { AlbumModel } from '../../album/models/album.model'
import { UserModel } from '@/src/modules/auth/account/models/user.model'

@ObjectType()
export class SongModel implements Song {
	@Field(() => String)
	id: string

	@Field(() => String)
	title: string

	@Field(() => String)
	albumId: string

	@Field(() => AlbumModel)
	album: AlbumModel

	@Field(() => [ArtistModel])
	artists: ArtistModel[]

	@Field(() => Number)
	duration: number

	@Field(() => String)
	audioUrl: string

	@Field(() => [String])
	genres: string[]

	@Field(() => String)
	coverUrl: string

	@Field(() => UserModel)
	uploader: UserModel

	@Field(() => String)
	uploaderId: string;

	@Field(() => [UserModel])
	users: UserModel[]

	@Field(() => Date)
	createdAt: Date

	@Field(() => Date)
	updatedAt: Date
}
