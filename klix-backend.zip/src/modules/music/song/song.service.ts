import { Injectable } from '@nestjs/common'
import * as Upload from 'graphql-upload/Upload.js'
import { v4 as uuid } from 'uuid'

import { Prisma, User } from '@/prisma/generated'
import { PrismaService } from '@/src/core/prisma/prisma.service'

import { StorageService } from '../../libs/storage/storage.service'
import { ArtistService } from '../artist/artist.service'

import { CreateSongInput } from './inputs/create-song.input'
import { FiltersInput } from './inputs/filters.input'

@Injectable()
export class SongService {
	constructor(
		private readonly prismaService: PrismaService,
		private readonly artistService: ArtistService,
		private readonly storageService: StorageService
	) {}

	async uploadSong(file: Upload & { duration?: number }) {
		const fileName = `/songs/${uuid()}`

		await this.storageService.upload(file, fileName, 'audio')

		const { duration } = file

		return {
			audioUrl: fileName,
			duration
		}
	}

	async uploadCover(file: Upload) {
		const fileName = `/covers/${uuid()}`

		await this.storageService.upload(file, fileName, 'image/webp')

		return fileName
	}

	async getSongs(input: FiltersInput = {}) {
		const { take, skip, searchTerm } = input

		const whereClause = searchTerm ? this.search(searchTerm) : undefined

		const songs = await this.prismaService.song.findMany({
			take: take ?? 12,
			skip: skip ?? 0,
			where: {
				...whereClause
			},
			include: {
				artists: true
			}
		})

		return songs
	}

	private search(searchTerm: string): Prisma.SongWhereInput {
		return {
			OR: [
				{
					title: {
						contains: searchTerm,
						mode: 'insensitive'
					},
					artists: {
						some: {
							name: {
								contains: searchTerm,
								mode: 'insensitive'
							}
						}
					}
				}
			]
		}
	}

	async createSong(user: User, input: CreateSongInput) {
		const { title, artists, genres, albumId, duration, audioUrl } = input

		const artistIds: string[] = []
		for (const artist of artists) {
			const artistItem = await this.artistService.createArtist({
				name: artist
			})
			artistIds.push(artistItem.id)
		}

		await this.prismaService.song.create({
			data: {
				title,
				genres,
				duration,
				audioUrl,
				album: {
					connect: {
						id: albumId
					}
				},
				artists: {
					connect: artistIds.map(id => ({ id }))
				},
				uploader: {
					connect: {
						id: user.id
					}
				}
			}
		})

		return true
	}
}
