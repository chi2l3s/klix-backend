import { Field, InputType } from '@nestjs/graphql'

@InputType()
export class CreateSongInput {
	@Field(() => String)
	title: string

	@Field(() => [String])
	artists: string[]

	@Field(() => String, { nullable: true })
	albumId?: string

	@Field(() => [String])
	genres: string[]

	@Field(() => Number)
	duration: number

	@Field(() => String)
	audioUrl: string
}
