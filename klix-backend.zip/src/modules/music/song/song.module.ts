import { Module } from '@nestjs/common';
import { SongService } from './song.service';
import { SongResolver } from './song.resolver';
import { ArtistService } from '../artist/artist.service';

@Module({
  providers: [SongResolver, SongService, ArtistService],
})
export class SongModule {}
