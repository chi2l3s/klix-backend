import { Args, Mutation, Query, Resolver } from '@nestjs/graphql'
import * as GraphQLUpload from 'graphql-upload/GraphQLUpload.js'
import * as Upload from 'graphql-upload/Upload.js'

import { User } from '@/prisma/generated'
import { Authorization } from '@/src/shared/decorators/auth.decorator'
import { Authorized } from '@/src/shared/decorators/authorized.decorator'
import { FileValidationPipe } from '@/src/shared/pipes/file-validation.pipe'
import { MusicValidationPipe } from '@/src/shared/pipes/music-validations.pipes'

import { CreateSongInput } from './inputs/create-song.input'
import { FiltersInput } from './inputs/filters.input'
import { SongModel } from './models/song.model'
import { UploadSongModel } from './models/upload-song.model'
import { SongService } from './song.service'

@Resolver('Song')
export class SongResolver {
	constructor(private readonly songService: SongService) {}

	@Authorization()
	@Mutation(() => UploadSongModel, { name: 'uploadSong' })
	async uploadSong(
		@Args('audio', { type: () => GraphQLUpload }, MusicValidationPipe)
		audio: Upload
	) {
		return this.songService.uploadSong(audio)
	}

	@Authorization()
	@Mutation(() => String, { name: 'uploadCover' })
	async uploadCover(
		@Args('cover', { type: () => GraphQLUpload }, FileValidationPipe)
		cover: Upload
	) {
		return this.songService.uploadCover(cover)
	}

	@Query(() => [SongModel], { name: 'getSongs' })
	async getSongs(@Args('data') input: FiltersInput) {
		return this.songService.getSongs(input)
	}

	@Authorization()
	@Mutation(() => Boolean, { name: 'createSong' })
	async createSong(
		@Authorized() user: User,
		@Args('data') input: CreateSongInput
	) {
		return this.songService.createSong(user, input)
	}
}
