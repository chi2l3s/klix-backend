import {
	ArgumentMetadata,
	BadRequestException,
	Injectable,
	PipeTransform
} from '@nestjs/common'
import { ReadStream } from 'fs'
import { parseStream } from 'music-metadata'

import { validateFileFormat, validateFileSize } from '../utils/file.util'

@Injectable()
export class MusicValidationPipe implements PipeTransform {
	async transform(value: any, metadata: ArgumentMetadata) {
		if (!value.fileName) {
			throw new BadRequestException('Файл не загружен')
		}

		const { fileName, createReadStream } = value

		const fileStream = createReadStream() as ReadStream

		const allowedFormats = ['mp4', 'wav', 'mpeg']
		const isFileFormatValid = validateFileFormat(fileName, allowedFormats)

		if (!isFileFormatValid) {
			throw new BadRequestException('Недопустимый формат файла')
		}

		const isFileSizeValid = await validateFileSize(
			fileStream,
			20 * 1024 * 1024
		)

		if (!isFileSizeValid) {
			throw new BadRequestException('Размер файла превышает 20 МБ')
		}

		fileStream.pause()
		const durationStream = createReadStream() as ReadStream
		const metadataResult = await parseStream(
			durationStream,
			{ mimeType: undefined },
			{ duration: true }
		)
        const duration = metadataResult.format.duration

        return {
            ...value,
            duration
        }
	}
}
